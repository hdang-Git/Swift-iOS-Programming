//
//  ViewController.swift
//  Basics
//
//  Created by serc456 on 11/13/17.
//  Copyright © 2017 serc456. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var textFieldLabel: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nameLabel.text = "Changed with code!!"
        textFieldLabel.delegate = self
    }

    @IBAction func tabMeButton(sender: AnyObject) {
//        nameLabel.text = "Changed wih Loading"
        let name = textFieldLabel.text
        nameLabel.text = "Hi \(name ?? "User")!"
        textFieldLabel.resignFirstResponder()
    }
    
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        view.endEditing(true)
        return false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

